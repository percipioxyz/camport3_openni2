/** Automatically generated file. DO NOT MODIFY */
package org.openni.android.samples.simpleviewer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}